package com.example.domain;

import com.example.dto.DepartmentDto;
import com.example.dto.OrganizationDto;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
public class Employee extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String name;

    @Positive
    private int age;

    @NotBlank
    private String position;

    @NotNull
    private Long organizationId;

    @NotNull
    private Long departmentId;

    @Transient
    private OrganizationDto organizationDto;

    @Transient
    private DepartmentDto departmentDto;

    @Transient
    private boolean isOrganisationless;

    @Transient
    private boolean isDepartmentLess;



    public Employee() {
    }

    public Employee(@NotBlank String name, @Positive int age, @NotBlank String position, @NotNull Long organizationId, @NotNull Long departmentId) {
        this.name = name;
        this.age = age;
        this.position = position;
        this.organizationId = organizationId;
        this.departmentId = departmentId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public @NotBlank String getName() {
        return name;
    }

    public void setName(@NotBlank String name) {
        this.name = name;
    }

    @Positive
    public int getAge() {
        return age;
    }

    public void setAge(@Positive int age) {
        this.age = age;
    }

    public @NotBlank String getPosition() {
        return position;
    }

    public void setPosition(@NotBlank String position) {
        this.position = position;
    }

    public @NotNull Long getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(@NotNull Long organizationId) {
        this.organizationId = organizationId;
    }

    public @NotNull Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(@NotNull Long departmentId) {
        this.departmentId = departmentId;
    }

    public OrganizationDto getOrganizationDto() {
        return organizationDto;
    }

    public void setOrganizationDto(OrganizationDto organizationDto) {
        this.organizationDto = organizationDto;
    }

    public DepartmentDto getDepartmentDto() {
        return departmentDto;
    }

    public void setDepartmentDto(DepartmentDto departmentDto) {
        this.departmentDto = departmentDto;
    }

    public boolean isDepartmentLess() {
        return isDepartmentLess;
    }

    public void setDepartmentLess(boolean departmentLess) {
        isDepartmentLess = departmentLess;
    }

    public boolean isOrganisationless() {
        return isOrganisationless;
    }

    public void setOrganisationless(boolean organisationless) {
        isOrganisationless = organisationless;
    }


}