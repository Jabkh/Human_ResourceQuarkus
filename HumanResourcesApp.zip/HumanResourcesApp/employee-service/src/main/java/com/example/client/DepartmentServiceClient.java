package com.example.client;

import com.example.dto.DepartmentDto;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import jakarta.ws.rs.*;



@Path("/departments")
@RegisterRestClient(configKey = "department-service")
public interface DepartmentServiceClient {

        @GET
        @Path("/{id}")
        DepartmentDto getDepartmentById(@PathParam("id") Long id);

        @GET
        @Path("/name/{name}")
        DepartmentDto getDepartmentByName(@PathParam("name") String name);

        @POST
        DepartmentDto createDepartment(DepartmentDto departmentDto);

        @PUT
        @Path("/{id}")
        DepartmentDto updateDepartment(@PathParam("id") Long id, DepartmentDto departmentDto);

        @DELETE
        @Path("/{id}")
        void deleteDepartment(@PathParam("id") Long id);
}
