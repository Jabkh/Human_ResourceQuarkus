package com.example.repository;

import com.example.domain.Employee;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;

import java.util.List;

@ApplicationScoped
public class EmployeeRepository implements PanacheRepository<Employee> {
    // PanacheRepository provides basic CRUD methods

    public Employee findByName(String name) {
        return find("name", name).firstResult();
    }

    public List<Employee> findByDepartmentId(Long departmentId) {
        return list("departmentId", departmentId);
    }

    public List<Employee> findByOrganizationId(Long organizationId) {
        return list("organizationId", organizationId);
    }

    public List<Employee> findWithoutDepartment() {
        return list("departmentId IS NULL");
    }

    public List<Employee> findWithoutOrganization() {
        return list("organizationId IS NULL");
    }
}