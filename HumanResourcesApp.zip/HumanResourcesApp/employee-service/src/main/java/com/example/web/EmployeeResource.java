// EmployeeResource.java
package com.example.web;

import com.example.domain.Employee;
import com.example.service.EmployeeService;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;
import java.util.Optional;

@Path("/employees")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class EmployeeResource {

    @Inject
    EmployeeService employeeService;

    @GET
    public List<Employee> listAll() {
        return employeeService.listAll();
    }

    @GET
    @Path("/department/{departmentId}")
    public List<Employee> getEmployeesByDepartment(@PathParam("departmentId") Long departmentId) {
        return employeeService.findByDepartmentId(departmentId);
    }

    @GET
    @Path("/organization/{organizationId}")
    public List<Employee> getEmployeesByOrganization(@PathParam("organizationId") Long organizationId) {
        return employeeService.findByOrganizationId(organizationId);
    }

    @GET
    @Path("/without-department")
    public List<Employee> getEmployeesWithoutDepartment() {
        return employeeService.findWithoutDepartment();
    }

    @GET
    @Path("/without-organization")
    public List<Employee> getEmployeesWithoutOrganization() {
        return employeeService.findWithoutOrganization();
    }

    @POST
    @Transactional
    public Response createEmployee(Employee employee) {
        employeeService.createEmployee(employee);
        return Response.status(Response.Status.CREATED).entity(employee).build();
    }

    @PUT
    @Path("/{id}")
    @Transactional
    public Response updateEmployee(@PathParam("id") Long id, Employee updatedEmployee) {
        Optional<Employee> employeeOptional = employeeService.updateEmployee(id, updatedEmployee);
        if (employeeOptional.isPresent()) {
            return Response.ok(employeeOptional.get()).build();
        } else {
            throw new NotFoundException("Employee not found with id: " + id);
        }
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public Response deleteEmployee(@PathParam("id") Long id) {
        boolean deleted = employeeService.deleteEmployee(id);
        if (deleted) {
            return Response.noContent().build();
        } else {
            throw new NotFoundException("Employee not found with id: " + id);
        }
    }

    @GET
    @Path("/{id}")
    public Response findById(@PathParam("id") Long id) {
        Optional<Employee> employeeOptional = employeeService.findById(id);
        if (employeeOptional.isPresent()) {
            return Response.ok(employeeOptional.get()).build();
        } else {
            throw new NotFoundException("Employee not found with id: " + id);
        }
    }
}