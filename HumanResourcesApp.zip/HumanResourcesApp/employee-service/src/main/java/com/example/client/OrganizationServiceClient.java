package com.example.client;

import com.example.dto.OrganizationDto;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import jakarta.ws.rs.*;

@Path("/organizations")
@RegisterRestClient(configKey = "organization-service")
public interface OrganizationServiceClient {

    @GET
    @Path("/{id}")
    OrganizationDto getOrganizationById(@PathParam("id") Long id);

    @GET
    @Path("/name/{name}")
    OrganizationDto getOrganizationByName(@PathParam("name") String name);

    @POST
    OrganizationDto createOrganization(OrganizationDto organizationDto);

    @PUT
    @Path("/{id}")
    OrganizationDto updateOrganization(@PathParam("id") Long id, OrganizationDto organizationDto);

    @DELETE
    @Path("/{id}")
    void deleteOrganization(@PathParam("id") Long id);

}