// EmployeeService.java
package com.example.service;

import com.example.domain.Employee;
import com.example.repository.EmployeeRepository;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;

import java.util.List;
import java.util.Optional;

public class EmployeeService {

    @Inject
    EmployeeRepository employeeRepository;

    public List<Employee> listAll() {
        return employeeRepository.listAll();
    }

    @Transactional
    public Employee createEmployee(Employee employee) {
        employeeRepository.persist(employee);
        return employee;
    }

    @Transactional
    public Optional<Employee> updateEmployee(Long id, Employee updatedEmployee) {
        Optional<Employee> employeeOptional = employeeRepository.findByIdOptional(id);
        if (employeeOptional.isPresent()) {
            Employee employee = employeeOptional.get();
            employee.setName(updatedEmployee.getName());
            employee.setAge(updatedEmployee.getAge());
            employee.setPosition(updatedEmployee.getPosition());
            employee.setOrganizationId(updatedEmployee.getOrganizationId());
            employee.setDepartmentId(updatedEmployee.getDepartmentId());
            return Optional.of(employee);
        }
        return Optional.empty();
    }

    @Transactional
    public boolean deleteEmployee(Long id) {
        return employeeRepository.deleteById(id);
    }

    public Optional<Employee> findById(Long id) {
        return employeeRepository.findByIdOptional(id);
    }

    public Employee findEmployeeById(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId);
        if (employee == null) {
            throw new NotFoundException("Employee not found with id: " + employeeId);
        }
        return employee;
    }

    public List<Employee> findByDepartmentId(Long departmentId) {
        return employeeRepository.findByDepartmentId(departmentId);
    }

    public List<Employee> findByOrganizationId(Long organizationId) {
        return employeeRepository.findByOrganizationId(organizationId);
    }

    public List<Employee> findWithoutDepartment() {
        return employeeRepository.findWithoutDepartment();
    }

    public List<Employee> findWithoutOrganization() {
        return employeeRepository.findWithoutOrganization();
    }
}