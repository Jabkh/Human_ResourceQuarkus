package com.example.service;

import com.example.domain.Department;
import com.example.repository.DepartmentRepository;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;

import java.util.List;
import java.util.Optional;

public class DepartmentService {

    @Inject
    DepartmentRepository departmentRepository;

    public List<Department> listAll() {
        return departmentRepository.listAll();
    }

    @Transactional
    public Department createDepartment(Department department) {
        departmentRepository.persist(department);
        return department;
    }

    @Transactional
    public Optional<Department> updateDepartment(Long id, Department updatedDepartment) {
        Optional<Department> departmentOptional = departmentRepository.findByIdOptional(id);
        if (departmentOptional.isPresent()) {
            Department department = departmentOptional.get();
            department.setName(updatedDepartment.getName());
            department.setOrganizationId(updatedDepartment.getOrganizationId());
            return Optional.of(department);
        }
        return Optional.empty();
    }

    @Transactional
    public boolean deleteDepartment(Long id) {
        return departmentRepository.deleteById(id);
    }

    public Optional<Department> findById(Long id) {
        return departmentRepository.findByIdOptional(id);
    }

    public Department findDepartmentById(Long departmentId) {
        Department department = departmentRepository.findById(departmentId);
        if (department == null) {
            throw new NotFoundException("Department not found with id: " + departmentId);
        }
        return department;
    }
}