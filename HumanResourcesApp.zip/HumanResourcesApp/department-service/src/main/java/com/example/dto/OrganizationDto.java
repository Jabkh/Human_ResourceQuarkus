package com.example.dto;

import java.time.LocalDate;

public class OrganizationDto {
    private Long id;
    private String name;
    private String address;
    private Integer numberOfEmployees;
    private LocalDate employeeArrivalDate;
    private LocalDate employeeDepartureDate;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getNumberOfEmployees() {
        return numberOfEmployees;
    }

    public void setNumberOfEmployees(Integer numberOfEmployees) {
        this.numberOfEmployees = numberOfEmployees;
    }

    public LocalDate getEmployeeArrivalDate() {
        return employeeArrivalDate;
    }

    public void setEmployeeArrivalDate(LocalDate employeeArrivalDate) {
        this.employeeArrivalDate = employeeArrivalDate;
    }

    public LocalDate getEmployeeDepartureDate() {
        return employeeDepartureDate;
    }

    public void setEmployeeDepartureDate(LocalDate employeeDepartureDate) {
        this.employeeDepartureDate = employeeDepartureDate;
    }
}