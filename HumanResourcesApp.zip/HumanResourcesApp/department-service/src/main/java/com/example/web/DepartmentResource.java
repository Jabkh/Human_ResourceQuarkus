package com.example.web;

import com.example.domain.Department;
import com.example.service.DepartmentService;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;
import java.util.Optional;

@Path("/departments")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class DepartmentResource {

    @Inject
    DepartmentService departmentService;

    @GET
    public List<Department> listAll() {
        return departmentService.listAll();
    }

    @POST
    @Transactional
    public Response createDepartment(Department department) {
        departmentService.createDepartment(department);
        return Response.status(Response.Status.CREATED).entity(department).build();
    }

    @PUT
    @Path("/{id}")
    @Transactional
    public Response updateDepartment(@PathParam("id") Long id, Department updatedDepartment) {
        Optional<Department> departmentOptional = departmentService.updateDepartment(id, updatedDepartment);
        if (departmentOptional.isPresent()) {
            return Response.ok(departmentOptional.get()).build();
        } else {
            throw new NotFoundException("Department not found with id: " + id);
        }
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public Response deleteDepartment(@PathParam("id") Long id) {
        boolean deleted = departmentService.deleteDepartment(id);
        if (deleted) {
            return Response.noContent().build();
        } else {
            throw new NotFoundException("Department not found with id: " + id);
        }
    }

    @GET
    @Path("/{id}")
    public Response findById(@PathParam("id") Long id) {
        Optional<Department> departmentOptional = departmentService.findById(id);
        if (departmentOptional.isPresent()) {
            return Response.ok(departmentOptional.get()).build();
        } else {
            throw new NotFoundException("Department not found with id: " + id);
        }
    }
}