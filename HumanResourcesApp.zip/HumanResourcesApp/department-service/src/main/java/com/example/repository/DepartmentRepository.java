package com.example.repository;

import com.example.domain.Department;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class DepartmentRepository implements PanacheRepository<Department> {
    // PanacheRepository provides basic CRUD methods

    public Department findByName(String name) {
        return find("name", name).firstResult();
    }
}