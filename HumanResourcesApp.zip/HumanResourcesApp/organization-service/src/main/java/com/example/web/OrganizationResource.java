package com.example.web;

import com.example.domain.Organization;
import com.example.service.OrganizationService;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;
import java.util.Optional;

@Path("/organizations")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class OrganizationResource {

    @Inject
    OrganizationService organizationService;

    @GET
    public List<Organization> listAll() {
        return organizationService.listAll();
    }

    @POST
    @Transactional
    public Response createOrganization(Organization organization) {
        organizationService.createOrganization(organization);
        return Response.status(Response.Status.CREATED).entity(organization).build();
    }

    @PUT
    @Path("/{id}")
    @Transactional
    public Response updateOrganization(@PathParam("id") Long id, Organization updatedOrganization) {
        Optional<Organization> organizationOptional = organizationService.updateOrganization(id, updatedOrganization);
        if (organizationOptional.isPresent()) {
            return Response.ok(organizationOptional.get()).build();
        } else {
            throw new NotFoundException("Organization not found with id: " + id);
        }
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public Response deleteOrganization(@PathParam("id") Long id) {
        boolean deleted = organizationService.deleteOrganization(id);
        if (deleted) {
            return Response.noContent().build();
        } else {
            throw new NotFoundException("Organization not found with id: " + id);
        }
    }

    @GET
    @Path("/{id}")
    public Response findById(@PathParam("id") Long id) {
        Optional<Organization> organizationOptional = organizationService.findById(id);
        if (organizationOptional.isPresent()) {
            return Response.ok(organizationOptional.get()).build();
        } else {
            throw new NotFoundException("Organization not found with id: " + id);
        }
    }
}