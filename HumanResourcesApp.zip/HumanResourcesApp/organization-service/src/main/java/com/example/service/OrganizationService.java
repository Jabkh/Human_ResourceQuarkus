package com.example.service;

import com.example.domain.Organization;
import com.example.repository.OrganizationRepository;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;

import java.util.List;
import java.util.Optional;

public class OrganizationService {

    @Inject
    OrganizationRepository organizationRepository;

    public List<Organization> listAll() {
        return organizationRepository.listAll();
    }

    @Transactional
    public Organization createOrganization(Organization organization) {
        organizationRepository.persist(organization);
        return organization;
    }

    @Transactional
    public Optional<Organization> updateOrganization(Long id, Organization updatedOrganization) {
        Optional<Organization> organizationOptional = organizationRepository.findByIdOptional(id);
        if (organizationOptional.isPresent()) {
            Organization organization = organizationOptional.get();
            organization.setName(updatedOrganization.getName());
            organization.setAddress(updatedOrganization.getAddress());
            organization.setNumberOfEmployees(updatedOrganization.getNumberOfEmployees());
            organization.setEmployeeArrivalDate(updatedOrganization.getEmployeeArrivalDate());
            organization.setEmployeeDepartureDate(updatedOrganization.getEmployeeDepartureDate());
            return Optional.of(organization);
        }
        return Optional.empty();
    }

    @Transactional
    public boolean deleteOrganization(Long id) {
        return organizationRepository.deleteById(id);
    }

    public Optional<Organization> findById(Long id) {
        return organizationRepository.findByIdOptional(id);
    }

    public Organization findOrganizationById(Long organizationId) {
        Organization organization = organizationRepository.findById(organizationId);
        if (organization == null) {
            throw new NotFoundException("Organization not found with id: " + organizationId);
        }
        return organization;
    }
}