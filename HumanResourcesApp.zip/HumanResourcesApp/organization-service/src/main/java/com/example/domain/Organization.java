package com.example.domain;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.Entity;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
public class Organization extends PanacheEntity {

    @NotBlank
    public String name;

    @NotBlank
    public String address;

    @NotNull
    public Integer numberOfEmployees;

    @NotNull
    public LocalDate employeeArrivalDate;

    public LocalDate employeeDepartureDate;

    public Organization() {
    }

    public Organization(String name, String address, Integer numberOfEmployees, LocalDate employeeArrivalDate, LocalDate employeeDepartureDate) {
        this.name = name;
        this.address = address;
        this.numberOfEmployees = numberOfEmployees;
        this.employeeArrivalDate = employeeArrivalDate;
        this.employeeDepartureDate = employeeDepartureDate;
    }

    public @NotBlank String getName() {
        return name;
    }

    public void setName(@NotBlank String name) {
        this.name = name;
    }

    public @NotBlank String getAddress() {
        return address;
    }

    public void setAddress(@NotBlank String address) {
        this.address = address;
    }

    public @NotNull Integer getNumberOfEmployees() {
        return numberOfEmployees;
    }

    public void setNumberOfEmployees(@NotNull Integer numberOfEmployees) {
        this.numberOfEmployees = numberOfEmployees;
    }

    public @NotNull LocalDate getEmployeeArrivalDate() {
        return employeeArrivalDate;
    }

    public void setEmployeeArrivalDate(@NotNull LocalDate employeeArrivalDate) {
        this.employeeArrivalDate = employeeArrivalDate;
    }

    public LocalDate getEmployeeDepartureDate() {
        return employeeDepartureDate;
    }

    public void setEmployeeDepartureDate(LocalDate employeeDepartureDate) {
        this.employeeDepartureDate = employeeDepartureDate;
    }
}