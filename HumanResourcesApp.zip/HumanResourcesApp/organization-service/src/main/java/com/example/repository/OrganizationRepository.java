package com.example.repository;

import com.example.domain.Organization;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class OrganizationRepository implements PanacheRepository<Organization> {
    // PanacheRepository provides basic CRUD methods

    public Organization findByName(String name) {
        return find("name", name).firstResult();
    }
}